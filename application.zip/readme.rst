#######################
REST API Documentations
########################

Refer https://github.com/Ajeetaryan56/getmaidapp/wiki/REST-API-Implementation-Guide